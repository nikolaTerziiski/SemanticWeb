# SemanticWeb
Project for the course Semantic Web in FMI
